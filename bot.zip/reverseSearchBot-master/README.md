[@reverseSearchBot](https://t.me/reverseSearchBot)

Finds the source of an image/GIF/sticker/video or identify the anime character, show, episode & time from its screenshot. Also works in groups if you reply to an image with commands "/source" and "/sauce". Use the inline mode for URL lookups and sharing the sauce with buttons.

Scrapes from ~~Tineye~~ (fuck) and Saucenow. Doesn't use the standard API.

A more user friendly and functional rewrite of https://github.com/cod119/TeleSaucenao_bot

Cloning:
Rename settings/private.js.example to .js after putting the required keys/tokens and constants.

Usage:
npm i
npm i -g pm2
npm start or node sauceBot.js
